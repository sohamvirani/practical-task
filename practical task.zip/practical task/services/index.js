module.exports.userServices = require("./user.service")
module.exports.postServices = require("./post.service")
