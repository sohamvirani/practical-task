module.exports.userSchema = require("./user.model");
module.exports.postSchema = require("./post.model");