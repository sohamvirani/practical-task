module.exports.usercontroller = require("./user.controller");
module.exports.postcontroller = require("./post.controller")
